=== Image Gallery ===
Contributors: Huge-IT
Donate link: http://huge-it.com/wordpress-gallery/
Tags: gallery, image gallery, gallery image, content slider, widget gallery, lightbox gallery, website gallery, gallery lightbox, image, images, post, posts, content gallery, galleries, wordpress gallery, Picture Gallery, nextgen, nextgen gallery, photo gallery, galeria, gallery, best gallery, thumbnail view, content gallery, media gallery, easy gallery, picture, gallery plugin, plugin gallery, wordpress photo gallery plugin, photos, photo, add gallery, add image, add picture, add photo, galery, add images, add pictures, gallery wordpress, widget, wp gallery, thumbnail, thumbnails, gallery slider, Galleria, simple gallery, img, admin, wordpress gallery plugin, thumbs, media, free gallery, free images, video gallery, youtube gallery, vimeo gallery, youtube, photo albums, vimeo, grid gallery, sidebar, responsive, images gallery, video, filterable gallery, grid, iphone gallery, shortcode, videos, seo, photogallery, photoset, shortcode gallery, fullscreen gallery, justified, demo, lightbox, fullscreen slider, gallery shortcode, free photo gallery, free, best gallery plugin, photo album, image rotator, free slider, banner rotator, album, galeri, galerie, image album, wp gallery plugins, pictures, revolution, responsive gallery, image gallery plugin,
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 1.1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Huge-IT Image Gallery is the best plugin to use if you want to be original with your website.

== Description ==

### Wordpress Image Gallery

* [Demo Image Gallery](http://huge-it.com/wordpress-plugins-gallery-demo/)
* [Demo Image Gallery Admin](http://huge-it.com/wordpress-plugins-gallery-demo-admin/)
* [User Image Gallery Manual](http://huge-it.com/wordpress-plugins-gallery-user-manual/)

https://www.youtube.com/watch?v=fNz0hW01k3k

Huge-IT Image Gallery is the best plugin to use if you want to be original with your website. Image Gallery has specially made to allow it’s users create a lot of ways to represent your images, videos and information. Just add image or video wright descriptions and titles for each view of the Image Gallery and choose one from 6 unrepeatable views. 

* Gallery / Content-Popup
* Content Slider 
* Ligthtbox Gallery
* Huge-IT Slider 
* Thumbnail view.
* Justified.

Each view has unique customizable options in “ General Options “ section to make them fit your taste. Almost every type of text can be change from the standpoint of text and color. Also there are a lot of features relative as to Image Gallery and thumbnails as to it's lightbox. Talking about Lightbox, notice, that Image Gallery plugin has separate options page, where you can choose one from 5 lightbox views, and customize it. And that way to create desirable style of your website. Show your image and video in it's best way!

Image Gallery plugin offers you, being already easy to use and friendly admin panel, where you can add several images and videos at a time and immediately give them a title, description and link, goes to any page, and set the way it opens. Huge-IT Image Gallery and all other plugins of our company have very high quality support so you always can be sure that you will not have any problems, with this plugin. Our experts are always ready to respond any your questions. With our Image Gallery you can realize your most original ideas. 6 views of the Image Gallery gives you 6 ways to be the best! Each view of Image Gallery is original, elegant and will fit to any styles of your images, videos and information. No matter to slide or show your media in thumbnails, or give them a useful information and show both together, whatever you choose will look original, because we worked hard on making Image Gallery irrepetible. So you can always be bold in your ideas with Huge-IT Image Gallery.

Considering the large number of galleries in WordPress, Huge-IT company day by day will improve and enhance the functionality of Image gallery, and keep on adhering to the first position among WordPress Gallery plugins. One of our new improvement is the video adding ability, besides images now you can also add any video you’d like from Youtube or Vimeo, just adding the video link you can get to show them in one of views. So We are sure our Image gallery will always satisfy you as our other 61,680+ users. Now just Install & Enjoy. All new information about new features and improvements that we made, you can find on our blog in the main page of Huge-it.com.

### The features of the Image Gallery

### 6 Views Options 

**Gallery / content-popup  -  Image Gallery**

This type of view Image Gallery view shows each post with it’s picture, title under text open in popup and make them larger. The button “View More” is under the text also inside the popup, it opens more information about the content. to close the popup press “cross” button and get back to the tape.

**Content slider  -  Image Gallery** 

In this view you can see your images with it’s text it’s title and “View More” button inside the slider. Just click on the arrows on the corners and move to the next.

**Ligthtbox gallery  -  Image Gallery**

This view of Image Gallery allows you to add your images without text. The title comes up in the bottom of the image as you hover on it. Images make larger with the lightbox and you can slide to watch them.

**Slider  -  Image Gallery**

If you know Slider and like it, you will be glad to set this view, because it is almost the same. Your picture with its title and description on the image, moves with many wonderful effects as you click on arrows.

**Thumbnails View  -  Image Gallery**

This view shows your images like thumbnail. As you click  they open in lightbox, and you can scroll them. there is not any text with it, only it’s title.

**Justified  -  Image Gallery**

Justified view allows you to represent your images and videos in a little sizes each next to other like a horizontal line or tape. By hovering on them, appears the title of the image/video. Clicking on the image / video it opens in lightbox, giving a beautiful view to them.


### If you think, that you found a bug in our [WordPress Image Gallery](http://huge-it.com/wordpress-gallery/) plugin or have any question contact us at [info@huge-it.com](mailto:info@huge-it.com).

== Installation ==

### First download the ZIP file ,

1. Log in to your website administrator panel.   
2. Go to Plugins page, and add new plugin.    
3. Upload [WordPress Image Gallery](http://wordpress.org/plugins/gallery-images). 
4. Click `Install Now` button.     
5. Then click `Activate Plugin` button. 

Now you can set your Image Gallery options, images and use our Image Gallery.

== Screenshots ==
    
1.  WordPress Image Gallery view 1 - Gallery / Content Popup
2.  WordPress Image Gallery view 2 - Content Slider
3.  WordPress Image Gallery view 3 - Lightbox Gallery
4.  WordPress Image Gallery view 4 - Slider
5.  WordPress Image Gallery view 5 - Thumbnails
6.  [WordPress Image Gallery](http://wordpress.org/plugins/gallery-images/) - Image Gallery admin page  
7.  [WordPress Image Gallery](http://wordpress.org/plugins/gallery-images/) - Image Gallery uploader
8.  [WordPress Image Gallery](http://wordpress.org/plugins/gallery-images/) - Image Gallery General options
9.  [WordPress Image Gallery](http://wordpress.org/plugins/gallery-images/) - Image Gallery add widget

== Frequently Asked Questions ==

### Image Gallery

**How to get a copy of most recent version ?**
Pro users can get update versions contacting us by info@huge-it.com.
Free version  users will find update notification in their wordpress admin panel.
 

**I have paid for pro version and didn’t get the link or file to update**
If you made purchase and didn’t get the file, or file was corrupt, contact us by info@huge-it.com and send “order number”, we will check and send you the file as soon as possible

**Have purchased pro version still get the announcement to buy the commercial version to change settings. What to do ?**
This can happen because of your browser’s cache files. Press ctrl+f5 (Chrome, FF) in order to clean them, if you use safari, etc., clean from browser settings

**Will I lose all my changes that I made in free version, if I update to pro version? **
All kind of changes made in free version will remain, even if you delete the plugin

**How to change “New Gallery” name?**
In order to change Image Gallery name just double click on it’s name (on top tabs)

**How to see the title of the image in lightbox?**
In order to add name to your image and see it in lightbox. 
Add attribute title=”X” in <a> tag of image code, where X is the name, 
Set “show the title” from Lightbox Options

**I have already purchased Multi Site version, how do I upgrade it to Developer version, without buying it again?**
If you have any pro version of our products and want to upgrade it, you do not need to buy the new one again, you only need to pay the difference price.
For example, if you have personal version and need to upgrade to Multi Site, just buy one more personal, and contact us by info@huge-it.com, send the receipt and we will send Multi Site version, from Multi Site to Developer, just buy one personal, and ask us for Developer version.

### If you think, that you found a bug in our [WordPress Image Gallery](http://huge-it.com/wordpress-gallery/) plugin or have any question contact us at [info@huge-it.com](mailto:info@huge-it.com).

== Changelog ==

= 1.1.7 =
*  Bug fixed in Image Gallery.

= 1.1.6 =
*  Bug fixed in Image Gallery.

= 1.1.5 =
*  Bug fixed in Image Gallery.

= 1.1.4 =
*  Two or more galleries on one page already available.

= 1.1.3 =
*  Bugs have been fixed on Image Gallery's lightbox.

= 1.1.2 =
*  Bug fixed in Image Gallery.

= 1.1.1 =
*  New awesome 'Justified' view has been launched in Image Gallery.

= 1.1.0 =
*  Notices errors has been fixed in Image Gallery.

= 1.0.8 =
*  Change view admin Bug fixed in Image Gallery.

= 1.0.8 =
*  Bug fixed in Image Gallery.

= 1.0.7 =
*  SQL Injection bag has been fixed in Image Gallery.

= 1.0.6 =
*  Bug fixed in Image Gallery.

= 1.0.5 =
*  Add image Bug fixed Image Gallery.

= 1.0.4 =
*  Bug fixed Image Gallery.

= 1.0.3 =
*  Bug fixed and added some features Image Gallery.

= 1.0.2 =
*  Bug fixed Image Gallery.

= 1.0.1 =
*  Bug fixed Image Gallery.

==Step 1. Adding a Image Gallery==

Huge-IT Image Gallery > Add New Image Gallery

Add Images. Use the standard WordPress Image uploader to add an image from media library or upload from computer.
Title. Add a title to your image
Description. give some information or describe the topic
URL. Provide some link of your post. Click to open in new tab or don’t click to open in the same tab

OR

Add videos. Use the standard WordPress video uploader to add a video from Youtube or Vimeo. Just insert a link 
Title. Add a title to your videos
Description. Give some information or describe the topic
URL. Provide some link of your post. Click to open in new tab or don’t click to open in the same tab


**Inserting Created Image Gallery** 

When you finish creating your Image Gallery. Find on the right site 3 blocks

Views. Here, among 6 views, mentioned above, chose the view for your Image Gallery. 

Usage. Here you can find a shortcode of your Image Gallery. You can Copy&Paste this shortcode wherever you need in your posts or page, where you want your Image Gallery be. Or you can add this code automatically, when posting your Image Gallery there is a button to add Image Gallery, pressing on it the shortcode inserts into your post.

Template Include. This code made to be inserted into your template, it makes the inserting Image Gallery easy for using in custom location within theme.

### Upgrade to [WordPress Image Gallery Pro](http://huge-it.com/wordpress-gallery/) to add some features:

### Step 2. General Options of Image Gallery

In this section you can modify your Image Gallery in more details. That will change the features of each view you choose.

2.1 **Gallery / content-popup  -  Image Gallery**

**Element Styles of Image Gallery**

Element Width. Sets the width of posted image in “ Image Gallery “

Element Height. Sets the high of posted image in “ Image Gallery “

Element Border Width. Set the border with of the element in “ Image Gallery “

Element Border Color. Choose the color for the border in “ Image Gallery “

Element's Image Overlay Color. Choose a color for the overlay on the image while hovering on it in Image Gallery

Element's Image Overlay Transparency. Set the level of transparency of the image overlay in “ Image Gallery “

Zoom Image Style. Changes the color of zoom icon in Image Gallery

**Popup Styles of Image Gallery**

Popup Background Color. Change the background color of popup in your “ Image Gallery “

Popup Overlay Color.Choose the color for popup overlay in your “ Image Gallery “

Popup Overlay Transparency. Set the level of background transparency in your “ Image Gallery “

Popup Close Button Style. Change the color of “X” icon. Image Gallery				

Show Separator Lines. Tick to show separation lines between title and text in popup of “ Image Gallery “

**Popup Description of Image Gallery**

Show Description. Tick to show the description of the image in your “ Image Gallery “

Description Font Size. Choose the size of description font in your “ Image Gallery “

Description Font Color. Change the color of description text in your “ Image Gallery “

**Element Title of Image Gallery**

Element Title Font Size. Change the size of title font in “ Image Gallery “

Element Title Background Color. Choose the color of title background in “ Image Gallery “

Element Title Font Color. Change the color of title in “ Image Gallery “

**Element Link Button of Image Gallery**

Show Link Button On Element. Tick to show “View More” button on the image. Image Gallery

Link Button Text. Change content of the “View More” text in “ Image Gallery “

Link Button Font Size. Change the size of link button in “ Image Gallery “

Link Button Font Color. Change the color of link font in “ Image Gallery “

Link Button Background Color. choose color for link background in “ Image Gallery “


**Popup Title of Image Gallery**

Popup Title Font Size. Choose title font size in your “ Image Gallery “ popup

Popup Title Font Color. Choose Title font color in popup. Image Gallery

**Popup Link Button of Image Gallery**

Show Link Button. Tick to show link button in popup of “ Image Gallery “

Link Button Text. Change the text of link button in popup of “ Image Gallery “

Link Button Font Size. Change font size of link button in popup of “ Image Gallery “

Link Button Font Color. Change color of link button in popup. Image Gallery

Link Button Font Hover Color. Choose color of link button when hover on it of “ Image Gallery “

Link Button Background Color. Set background color of the link button in popup of “ Image Gallery “

Link Button Background Hover Color. Set background color of the link as you hover on it. Image Gallery


2.2 **Content slider  -  Image Gallery**

**Slider of Image Gallery**

Slider Background Color. Set the color of background in “ Image Gallery “

Arrow Icons Style. Set black or white color of arrows in slider of “ Image Gallery “	
 		
Show Separator Lines. Click to show the lines between text, title, and link in “ Image Gallery “

**Title  -  Image Gallery**

Title Font Size. Set the font size of the title in “ Image Gallery “

Title Font Color. Set the color of the font in “ Image Gallery “

**Link Button  -  Image Gallery**

Show Link Button. Click to show the link button in “ Image Gallery “

Link Button Text. Change the text on link button in “ Image Gallery “

Link Button Font Size. Change the font size of the link text in “ Image Gallery “

Link Button Font Color. Change the color or the link text in “Image Gallery “

Link Button Font Hover Color. Change the color of the link text while hovering on it. Image Gallery

Link Button Background Color. Choose the color of link background in “ Image Gallery “

Link Button Background Hover Color. Choose the color of link background while hovering on it. Image Gallery

**Images  -  Image Gallery**

Main Image Width. Set the size of the image in “ Image Gallery “

**Description  -  Image Gallery**

Show Description. Click to show the description of the text in “ Image Gallery “

Description Font Size. Set the font size of description in “ Image Gallery “

Description Font Color. Set the color of font in description of “ Image Gallery “


2.3 **Ligthtbox gallery  -  Image Gallery**

**Image  -  Image Gallery**

Image Width. Set the size of the image in “ Image Gallery “

Image Border Width. Set the width of borders  in “ Image Gallery “

Image Border Color. Choose the color for border in “ Image Gallery “

Border Radius. Choose the radius of border corners in “ Image Gallery “

**Title  -  Image Gallery**

Title Font Size. Set the font size of the title in “ Image Gallery “

Title Font Color. Set the color of the title in “ Image Gallery “

Title Font Hover Color. Set the color of the title while hovering on it . Image Gallery

Title Background Color. Choose title background color in “ Image Gallery “

Title Background Transparency. Choose the level of title background transparency in “ Image Gallery “ 
 
2.4 **Slider  -  Image Gallery**

**Title  -  Image Gallery**

Title Width. Choose the width for title box in “ Image Gallery “

Title Has Margin. Click if you need the title to have margin in your “ Image Gallery “

Title Font Size. Set the font size of the title in “ Image Gallery “

Title Text Color. Set the color of the title in “ Image Gallery “

Title Text Align. Set the location of the title in the box in “ Image Gallery “			

Title Background Transparency. Set the level of background transparency in “ Image Gallery “

Title Background Color. Choose the color of title background in “ Image Gallery “

Title Border Size. Set the size of the title border in “ Image Gallery “

Title Border Color. Choose the color for the title border in “ Image Gallery “

Title Border Radius. Set the radius for border corners in “ Image Gallery “

Title Position. Choose the position for the title in “ Image Gallery “

**Slideshow  -  Image Gallery**

Image Behaviour. Choose resized if you need your images have the size of the slider in “ Image Gallery “

Slider Background Color. Choose the color of background while images has its natural size. Image Gallery

Slideshow Border Size. Set the size of the slider border in “ Image Gallery “

Slideshow Border Color. Choose the color for the slider border in “ Image Gallery “

Slideshow Border radius Choose the radius for slider border in “ Image Gallery “

**Description  -  Image Gallery**

Description Has Margin. Choose if description need to have margin  “ Image Gallery “

Description Font Size. Set the font size for description in “ Image Gallery “

Description Text Color. Set text color for description in “ Image Gallery “

Description Text Align. Set the location of the description in the box	 of “ Image Gallery “	

Description Background Transparency. Set the level of transparency for background of description. Image Gallery

Description Background Color. Choose the color for description background in “ Image Gallery “

Description Border Size. Set the size for the border in description of “ Image Gallery “

Description Border Color. Set the color of description border in “ Image Gallery “

Description Border Radius . Set the radius of the description box corners in “ Image Gallery “

Description Position. Set the position of description on image. Image Gallery

**Navigation  -  Image Gallery**

Show Navigation Arrows. Click to show navigation arrows in “ Image Gallery “ slider

Navigation Dots Position / Hide Dots. Choose the location for dots, or choose to remove them. Image Gallery

Navigation Dots Color. choose the color for navigation dots in “ Image Gallery “ slider

Navigation Active Dot Color. Choose the color of moving dots in “ Image Gallery “ slider

2.5 **Thumbnails View  -  Image Gallery**

**Image  -  Image Gallery**

Image Behavior. Click to give your images a behavior in your “ Image Gallery “

Image Width. Set the width of thumbs in “ Image Gallery “

Image Height. Set the height of thumbs in “ Image Gallery “

Image Border Width. Set the width of the border between thumbs in “ Image Gallery “

Image Border Color. Set the color of the border between thumbs in “ Image Gallery “

Border Radius. Set the radius of the border in “ Image Gallery “

Margin Image. Set the distance between each thumb in “ Image Gallery “

**Title  -  Image Gallery**

Title Font Size. Set the size of the text font in “ Image Gallery “

Title Font Color. Choose the color of text in “ Image Gallery “

Overlay Background Color. Choose the overlay color of the title in “ Image Gallery “

Title Background Transparency. Set the level of background transparency in “ Image Gallery “

**Box style  -  Image Gallery**

Box Has background. Click to have background for thumbs in “ Image Gallery “

Box background. Set the Color of surrounded box in “ Image Gallery “

Box Use shadow. Click if you need to have shadows in the box of “ Image Gallery “

Box padding. Set the distance between the box and images in “ Image Gallery “

2.6 **Justified View  -  Image Gallery**

**Element Styles  -  Image Gallery**

Image height. Set the height of the images/videos in tape

Image margin. Set the distance between each image/video in the tape

Image Justify. Select to make the width of all image/video up to 100% in container. So all them together will fit the container of your theme, and tick off to bring each of them with it’s natural size.

Image Randomize. Select to show your images randomly.

Opening With Animation. Choose to see the tape of images/videos appearing animated.

Opening Animation Speed. Select the speed of the animation.

**Element Title  -  Image Gallery**

Show Title. Choose to show the title or not

Element Title Font Size. Choose the font size for the title of the image / video

Element Title Font Color. Select preferable colour for the title of the image / video

Element Title Background Color. Choose the colour of title background 

Element's Title Overlay Transparency. Select the level of transparency for the title overlay

